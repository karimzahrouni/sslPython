#!/usr/bin/env python

import socket
import threading
import sys
import binascii
import argparse
from server import DEFAULT_PORT
from dhke import DH, DH_MSG_SIZE, LEN_PK
from cipher import Message
from cli import CLI


__author__ = "Zahrouni"
__license__ = "TEST"
__version__ = "0.1"
__status__ = "Development"


class Client:

    def __init__(self, interface, server_address, port=DEFAULT_PORT):
        self.cli = interface
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.cli.add_msg("Connecting to {}...".format(server_address))
        try:
            self.connection.connect((server_address, port))
        except KeyboardInterrupt:
            self.cli.clean_exit()
            sys.exit()
        self.cli.add_msg("Connected!")
        self.key = None

    def dh(self):
        self.cli.add_msg("Establishing Encryption Key...")
        dh_message = self.connection.recv(DH_MSG_SIZE)
        p, g, server_key = DH.unpack(dh_message)
        private_key = DH.gen_private_key()
        public_key = DH.gen_public_key(g, private_key, p)
        self.connection.sendall(DH.package(public_key, LEN_PK))
        shared_key = DH.get_shared_key(server_key, private_key, p)
        # print("Shared Key: {}".format(shared_key))
        self.cli.add_msg("Encryption Key: {}".format(binascii.hexlify(shared_key).decode("utf-8")))
        return shared_key

    def send(self, content):
        if not self.key:
            self.cli.add_msg("Error: Key Not Established")
            return
        msg = Message(key=self.key, plaintext=content)
        self.connection.sendall(msg.pack())

    def start(self):
        try:
            self.key = self.dh()
        except ConnectionError:
            self.cli.add_msg("Unable to Connect")
            return
        while True:
            try:
                data = self.connection.recv(1024)
                if not data:
                    self.connection.close()
                    self.cli.uninit_client()
                    break
                msg = Message(key=self.key, ciphertext=data)
                if not self.cli:
                    break
                self.cli.add_msg(msg.plaintext)
            except OSError:
                self.connection.close()
                self.cli.uninit_client()
                break


if __name__ == '__main__':
    interface = CLI()
    try:
        c = Client(interface, '127.0.0.1', DEFAULT_PORT)
    except ConnectionRefusedError:
        interface.clean_exit()
        print("Connection Refused")
        sys.exit()
    except OSError:
        interface.clean_exit()
        print("Connection Failed")
        sys.exit()
    interface.init_client(c)
    client_thread = threading.Thread(target=c.start)
    client_thread.start()
    try:
        interface.main()
    except KeyboardInterrupt:
        interface.clean_exit()
