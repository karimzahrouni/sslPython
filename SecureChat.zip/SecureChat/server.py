#!/usr/bin/env python
import socket
import threading
import sys
import binascii
import argparse
from M2Crypto import DH as M2DH
from dhke import DH, DH_SIZE, LEN_PK
from cipher import Message


__author__ = "Zahrouni"
__license__ = "TEST"
__version__ = "0.1"
__status__ = "Development"


BACKLOG = 5
DEFAULT_PORT = 8050
DEFAULT_HOST = '127.0.0.1' 


class Server:

    def __init__(self, host='127.0.0.1', port=DEFAULT_PORT):
        print("SecureChat Sever v{}".format(__version__))
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("Generating a {}-bit prime...".format(DH_SIZE))
        self.dh_params = M2DH.gen_params(DH_SIZE, 2)
        print("Done!")
        self.clients = []
        try:
            self.start()
        except KeyboardInterrupt:
            print("\rExiting...")
            [self.disconnect(client) for client in self.clients]
            self.socket.close()
            sys.exit()

    def start(self):
        self.socket.bind((self.host, self.port))
        print("Socket bound to {} on port {}".format(self.host, self.port))
        self.socket.listen(BACKLOG)
        print("Waiting for Clients...")
        while True:
            connection, address = self.socket.accept()
            print("{} has connected".format(address[0]))
            client = Client(self, connection, address)
            if not client.key:
                client.connection.close()
                print("{} has disconnected".format(client.address[0]))
                continue
            print("Client Key: {}".format(binascii.hexlify(client.key).decode("utf-8")))
            self.clients.append(client)
            self.broadcast("{} has joined".format(client.address[0]), client, show_address=False)
            threading.Thread(target=self.listen, args=(client, )).start()

    def listen(self, client):
        while True:
            try:
                data = client.connection.recv(1024)
                if not data:
                    self.disconnect(client)
                    break
                print("{} [Raw]: {}".format(client.address[0], data))
                msg = Message(key=client.key, ciphertext=data)
                print("{} [Decrypted]: {}".format(client.address[0], msg.plaintext))
                if msg.plaintext == "!exit":
                    client.send("Acknowledged")
                    self.disconnect(client)
                    continue
                self.broadcast(msg.plaintext, client)
            except OSError:
                self.disconnect(client)
                break

    def broadcast(self, content, from_client, show_address=True):
        if show_address:
            msg = from_client.address[0] + ": " + content
        else:
            msg = content
        [client.send(msg) for client in self.clients if client is not from_client]

    def disconnect(self, client):
        client.connection.close()
        if client in self.clients:
            disconnect_msg = "{} has disconnected".format(client.address[0])
            self.broadcast(disconnect_msg, client, show_address=False)
            try:
                self.clients.remove(client)
            except ValueError:
                pass
            print(disconnect_msg)


class Client:

    def __init__(self, server, connection, address, user=None):
        self.connection = connection
        self.address = address
        self.user = user
        self.key = self.dh(server.dh_params)

    def dh(self, dh_params):
        p = DH.b2i(dh_params.p)
        g = DH.b2i(dh_params.g)
        a = DH.gen_private_key()
        public_key = DH.gen_public_key(g, a, p)
        dh_message = bytes(DH(p, g, public_key))
        self.connection.sendall(dh_message)
        try:
            response = self.connection.recv(LEN_PK)
        except ConnectionError:
            print("Key Exchange with {} failed".format(self.address[0]))
            return None
        client_key = DH.b2i(response)
        shared_key = DH.get_shared_key(client_key, a, p)
        return shared_key

    def send(self, content):
        msg = Message(key=self.key, plaintext=content)
        self.connection.sendall(msg.pack())

    def decrypt(self, content):
        return Message(key=self.key, ciphertext=content).plaintext


if __name__ == '__main__':
    s = Server(DEFAULT_HOST, DEFAULT_PORT)

